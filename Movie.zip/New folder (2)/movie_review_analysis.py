
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from collections import Counter
from wordcloud import WordCloud


np.random.seed(42)
num_rows = 100
movie_titles = ["Movie " + chr(65 + i) for i in range(10)]
years = np.random.choice(range(2015, 2022), num_rows)
genres = np.random.choice(["Action", "Romance", "Thriller", "Drama", "Comedy"], num_rows)
ratings = np.round(np.random.uniform(5, 9, num_rows), 1)
review_counts = np.random.choice(range(300, 2000), num_rows)
reviews = np.random.choice([
    "Excellent movie, great scenes",
    "Decent movie, but a bit slow",
    "Kept me on the edge of my seat!",
    "Not my cup of tea, but well produced",
    "Amazing cinematography!",
    "Predictable plot but good performances",
    "Would watch again",
    "A bit overhyped",
    "Solid storyline and good acting",
    "An underrated gem"
], num_rows)
df = pd.DataFrame({
    'Movie Title': np.random.choice(movie_titles, num_rows),
    'Year': years,
    'Genre': genres,
    'Rating': ratings,
    'Review Count': review_counts,
    'Review Text': reviews
})

sns.histplot(df['Rating'], kde=True, bins=15, color='skyblue')
sns.countplot(data=df, x='Genre', order=df['Genre'].value_counts().index, palette="pastel")
avg_rating_by_year = df.groupby('Year')['Rating'].mean()
sns.lineplot(x=avg_rating_by_year.index, y=avg_rating_by_year.values, marker='o')

tokens_simple = df['Review Text'].str.lower().str.split().sum()
stop_words_simple = set([
    "and", "the", "is", "of", "to", "a", "in", "but", "on", "for", "with", "it", "an", "my", "me"
])
filtered_tokens_simple = [word for word in tokens_simple if word not in stop_words_simple]
word_freq_simple = Counter(filtered_tokens_simple)


wordcloud = WordCloud(width=800, height=400, background_color='white').generate_from_frequencies(word_freq_simple)
plt.figure(figsize=(12, 8))
plt.imshow(wordcloud, interpolation='bilinear')
plt.axis('off')
plt.title("Most Common Words in Reviews")
plt.show()